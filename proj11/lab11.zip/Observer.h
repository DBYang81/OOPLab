//
// Created by DBY on 8.12.2021.
//

#ifndef PROJ11_OBSERVER_H
#define PROJ11_OBSERVER_H
class Observer {
public:
    virtual void HandleLimitReached() = 0;
};
#endif //PROJ11_OBSERVER_H
